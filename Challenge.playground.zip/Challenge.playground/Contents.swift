import Foundation

/*
 
 Note:
 The challenge asked to pass a pricing rules table to the UnidaysDiscountChallenge class but I think it's more efficient and easier to store the discount type and discount data for each item instance. This way, it's easier to add items to the basket.
 
 */


// A delivery charge has a charge and an optional freeOver value which represents after how much total order the delivery is free
struct DeliveryCharge{
    var charge: Double
    var freeOver: Double?
}

// Four types of discounts possible
// 1. None -> no discont given
// 2. GetXforY -> user can buy X number of items for the price of Y
// 3. BuyXGetYFree -> user can buy X number of items and get Y number of items free
// 4. GetXforPriceOfY -> user can buy X number of items for the price of Y number of items
enum DiscountType{
    case none
    case getXforY(Int, Double)
    case buyXgetYFree(Int, Int)
    case getXforPriceOfY(Int, Int)
}

// Each item has a name, price and a configured discount type
struct Item{
    var name: String
    var price: Double
    var discountType: DiscountType
}

class UnidaysDiscountChallenge{
    // Basket is a dictionary and stores a list of items for each given item type
    private var basket = [String: [Item]]()
    // orderHistory is an array of the names of the items in the basket for debugging purposes
    var orderHistory = [String]()
    // Delivery fee must be configured
    var deliveryCharge: DeliveryCharge
    
    init(deliveryCharge: DeliveryCharge) {
        self.deliveryCharge = deliveryCharge
    }
    
    func addToBasket(item: Item){
        // Recording the name of the item in the array for debugging later
        orderHistory.append(item.name)
        
        // If it's the first of this item's type then a key-value pair is created in the dictionary
        if basket[item.name] == nil{
            basket[item.name] = [item]
        }else{
            // Otherwise the item is appended to its appropriate list
            basket[item.name]?.append(item)
        }
    }
    
    func calculateTotalPrice() -> (total: Double, deliveryCharge: Double){
        var total = 0.0
        var deliveryFee = 0.0
        
        // Iterating the basket dictionary, going by item type
        for items in basket.values{
            // All items in the list have the same price, discount type as they were added to their corresponding list in the addToBasket function
            let price = items[0].price
            let discountType = items[0].discountType
            
            switch discountType {
            case .none:
                total += (price * Double(items.count))
            case let .getXforY(getX, forY):
                let remainder = items.count % getX
                total += price * Double(remainder)
                total += Double(items.count / getX) * forY
            case let .buyXgetYFree(buyX, getY):
                let remainder = items.count % (buyX + getY)
                total += price * Double(remainder)
                total += Double(items.count / (buyX + getY)) * price
            case let .getXforPriceOfY(getX, priceOfY):
                let remainder = items.count % getX
                total += price * Double(remainder)
                total += Double(items.count / getX) * (price * Double(priceOfY))
            }
        }
        
        // Adding a delivery fee if there is no freeOver value provided or if the total is less than the freeOver value
        if deliveryCharge.freeOver == nil || total < deliveryCharge.freeOver!{
            deliveryFee = self.deliveryCharge.charge
        }
        
        return (total, deliveryFee)
    }
    
    // Clearing the basket and order history data for debugging
    func clearOrder(){
        basket.removeAll()
        orderHistory.removeAll()
    }
}

// Printing and formatting the test case results
func printTestResult(total: Double, deliveryCharge: Double, items: [String]) {
    if items.isEmpty{
        print("No items, total: £0.00, delivery charge: £0.00\n")
        return
    }
    
    print("Items: ", terminator: "")
    for (index, item) in items.enumerated(){
        print(item, terminator: "")
        if index != items.count-1{
            print(", ", terminator: "")
        }
    }
    
    print("\nTotal: £\(total), delivery charge: £\(deliveryCharge)\n")
}

// ITEMS
let itemA = Item(name: "A", price: 8.0, discountType: DiscountType.none)
let itemB = Item(name: "B", price: 12.0, discountType: DiscountType.getXforY(2, 20))
let itemC = Item(name: "C", price: 4.0, discountType: DiscountType.getXforY(3, 10))
let itemD = Item(name: "D", price: 7.0, discountType: DiscountType.buyXgetYFree(1, 1))
let itemE = Item(name: "E", price: 5.0, discountType: DiscountType.getXforPriceOfY(3, 2))

// TEST CASES
let unidaysDiscountChallenge = UnidaysDiscountChallenge(deliveryCharge: DeliveryCharge(charge: 7.0, freeOver: 50.0))

// None
var result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)

// A
unidaysDiscountChallenge.addToBasket(item: itemA)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// B
unidaysDiscountChallenge.addToBasket(item: itemB)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// C
unidaysDiscountChallenge.addToBasket(item: itemC)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// D
unidaysDiscountChallenge.addToBasket(item: itemD)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// E
unidaysDiscountChallenge.addToBasket(item: itemE)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// BB
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// BBB
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// BBBB
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// CCC
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// CCCC
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// DD
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// DDD
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// EE
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// EEE
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// EEEE
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// DDDDDDDDDDDDDD
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// BBBBCCC
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// ABBCCCDDEE
unidaysDiscountChallenge.addToBasket(item: itemA)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemE)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()

// EDCBAEDCBC
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemA)
unidaysDiscountChallenge.addToBasket(item: itemE)
unidaysDiscountChallenge.addToBasket(item: itemD)
unidaysDiscountChallenge.addToBasket(item: itemC)
unidaysDiscountChallenge.addToBasket(item: itemB)
unidaysDiscountChallenge.addToBasket(item: itemC)
result = unidaysDiscountChallenge.calculateTotalPrice()
printTestResult(total: result.total, deliveryCharge: result.deliveryCharge, items: unidaysDiscountChallenge.orderHistory)
unidaysDiscountChallenge.clearOrder()
